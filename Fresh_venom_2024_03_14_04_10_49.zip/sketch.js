class Mover { 
  constructor(x,y){ 
    this.location = createVector(x, y); 
    this.velocity = createVector(random(-4,4), random(-4,4)) 
    this.acceleration = createVector(0, 0); 
  }
  
  
  display(){ 
    noStroke(); 
    fill(0); 
    let r = random(25,40);
    ellipse(this.location.x, this.location.y, r, r); 
  } 
  
  update(){ 
    var mouse = createVector(mouseX, mouseY); 
    var dir = mouse.sub(this.location); 
    var topSpeed = 15
    dir.normalize(); 
    dir.mult(0.75); 
    this.velocity.add(this.acceleration); 
    this.velocity.add(dir); 
    this.velocity.limit(topSpeed) 
    this.location.add(this.velocity);
  } 
  
   cekUjung(){ 
    if ( this.location.x > windowWidth ) { 
      this.location.x = 0; 
    } 
    else if (this.location.x < 0){ 
      this.location.x = windowWidth; 
    } 
   
    if ( this.location.y > windowHeight ) { 
      this.location.y = 0; 
    } 
    else if (this.location.y < 0){ 
      this.location.y = windowHeight; 
    } 
  } 
}

let movers = [];
let mouse;
function setup() {
  createCanvas(windowWidth, windowHeight);
  
  for (let i=0; i<50;i++){
    movers[i] = new Mover(random(windowWidth), random(windowHeight));   
  }
 
}

function draw() {
  background(225);
      
  fill('purple')
      ellipse(mouseX, mouseY, 120, 155)
      ellipse(mouseX, mouseY, 15, 202)
      ellipse(mouseX, mouseY, 202, 15)
  fill('blue')
      ellipse(mouseX, mouseY, 75, 97)
    for (let i=0; i<50;i++){
      movers[i].cekUjung(); 
      movers[i].display(); 
      movers[i].update();    
  }
  
  
}